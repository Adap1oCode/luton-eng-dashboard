# Auth + DB Context Pack

This bundle focuses on **authentication and Supabase connectivity** for your Next.js app.

### What’s included
- **Helpers**: `src/lib/supabase.ts`, `src/lib/supabase-server.ts` (if present)
- **Server actions**: `src/server/**`
- **Middleware**: `middleware.ts` (root delegator, if present), `src/middleware.ts`, `src/middleware/**`
- **Auth UI/routes**: `src/app/(main)/auth/**` (login, actions, callback)
- **API routes**: `src/app/api/**` (e.g., db-check, health)
- **Dashboard guard**: `src/app/(main)/dashboard/layout.tsx`
- **Supabase project** (if committed): `/supabase/**` (migrations, functions)

### Extra artifacts
- `routes.json`: auth/api routes discovered
- `scan_auth_db_files.json`: files across `src/**` that reference Supabase/auth patterns
- `_full/**`: full copies of critical files/folders
- `_files/**` and `_snippets/**`: per-file content or head-only snippets (for large files)
- `dependencies.json`: deps and scripts from package.json

### Not included
- Secrets (`.env*`, keys, certs) and heavy build outputs (`.next/**`, `node_modules/**`)
- Large files are truncated to a head snippet to keep this pack compact.

### How this is used
Share this context pack to debug:
- SSR cookie wiring (`@supabase/ssr` getAll/setAll),
- middleware guards and redirects,
- auth UI flows (password + magic link),
- API handlers and DB access patterns.

