// src/app/(main)/dashboard/requisitions/page.tsx

import { getRequisitionMetrics, getRequisitions } from './_components/data'
import RequisitionClient from './_components/client'

const RANGE: '3m' | '6m' | '12m' = '3m'

export default async function RequisitionsPage() {
  const metrics = await getRequisitionMetrics(RANGE)
  const requisitions = await getRequisitions(RANGE)

  return <RequisitionClient metrics={metrics} requisitions={requisitions} />
}
