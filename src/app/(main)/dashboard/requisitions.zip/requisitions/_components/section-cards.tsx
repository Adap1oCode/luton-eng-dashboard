// src/app/(main)/dashboard/requisitions/_components/section-cards.tsx

'use client'

import { Badge } from '@/components/ui/badge'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
  CardAction,
} from '@/components/ui/card'
import { TrendingUp, TrendingDown } from 'lucide-react'

export type MetricTile = {
  title: string
  value: number
  trend: string
  direction: string
  subtitle: string
}

export default function SectionCards({ data }: { data: MetricTile[] }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {[...data].map((tile, i) => (
        <Card key={i} className="@container/card">
          <CardHeader>
            <CardDescription>{tile.title}</CardDescription>
            <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
              {tile.value.toLocaleString()}
            </CardTitle>
            {tile.trend && tile.direction && (
              <CardAction>
                <Badge variant="outline">
                  {tile.direction === 'up' ? <TrendingUp className="mr-1 h-4 w-4" /> : <TrendingDown className="mr-1 h-4 w-4" />}
                  {tile.trend}
                </Badge>
              </CardAction>
            )}
          </CardHeader>
          {tile.subtitle && (
            <CardFooter className="flex-col items-start gap-1.5 text-sm">
              <div className="line-clamp-1 flex gap-2 font-medium">
                {tile.subtitle}
                {tile.direction === 'up' ? <TrendingUp className="size-4" /> : <TrendingDown className="size-4" />}
              </div>
              <div className="text-muted-foreground">Last 3 months vs previous</div>
            </CardFooter>
          )}
        </Card>
      ))}
    </div>
  )
}
