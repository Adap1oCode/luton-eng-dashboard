// src/app/(main)/dashboard/requisitions/_components/client.tsx

'use client'

import { useState } from 'react'
import SectionCards from './section-cards'
import ChartAreaInteractive from './chart-area-interactive'
import ChartByStatus from './chart-by-status'
import ChartByCreator from './chart-by-creator'
import ChartByProject from './chart-by-project'
import ChartMissingData from './chart-missing-data'
import { DataTable } from './data-table'
import { getIssues, IssueType } from './get-issues'
import type { Requisition } from './data'

export default function RequisitionClient({
  metrics,
  requisitions,
}: {
  metrics: any
  requisitions: Requisition[]
}) {
  const [filters, setFilters] = useState<
    { type: 'status' | 'creator' | 'project' | 'issue'; value: string }[]
  >([])

  const handleFilter = (type: 'status' | 'creator' | 'project' | 'issue') => (values: string[]) => {
    const updated = values.map((val) => ({ type, value: val }))
    setFilters(updated)
  }

  const filteredData = filters.length === 0
    ? requisitions
    : requisitions.filter((row) =>
        filters.every((f: { type: string; value: string }) => {
          if (f.type === 'status') return row.status === f.value
          if (f.type === 'creator') return row.created_by === f.value
          if (f.type === 'project') return row.project_number === f.value
          if (f.type === 'issue') return getIssues(row).includes(f.value as IssueType)
          return true
        })
      )

  const tileData = [
    {
      title: 'Total Reqs',
      value: metrics.totalReqs.value,
      trend: metrics.totalReqs.trend,
      direction: metrics.totalReqs.direction,
      subtitle: metrics.totalReqs.subtitle,
    },
    {
      title: 'Closed - Pick Complete',
      value: metrics.closedReqs.value,
      trend: metrics.closedReqs.trend,
      direction: metrics.closedReqs.direction,
      subtitle: metrics.closedReqs.subtitle,
    },
    {
      title: 'Missing Order Date',
      value: metrics.missingOrderDate.value,
      trend: metrics.missingOrderDate.trend,
      direction: metrics.missingOrderDate.direction,
      subtitle: metrics.missingOrderDate.subtitle,
    },
    {
      title: 'Missing Due Date',
      value: metrics.missingDueDate.value,
      trend: metrics.missingDueDate.trend,
      direction: metrics.missingDueDate.direction,
      subtitle: metrics.missingDueDate.subtitle,
    },
  ]

  return (
    <div className="grid gap-4">
      <SectionCards data={tileData} />
      <ChartAreaInteractive data={requisitions} />
      <ChartMissingData data={requisitions} onFilterChange={handleFilter('issue')} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <ChartByStatus data={requisitions} onFilterChange={handleFilter('status')} />
        <ChartByCreator data={requisitions} onFilterChange={handleFilter('creator')} />
      </div>
      <ChartByProject data={requisitions} onFilterChange={handleFilter('project')} />
      <DataTable data={filteredData} />
    </div>
  )
}
