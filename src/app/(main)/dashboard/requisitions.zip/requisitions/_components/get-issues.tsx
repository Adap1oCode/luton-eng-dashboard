export type IssueType =
  | 'missing_order_date'
  | 'missing_due_date'
  | 'missing_created_by'
  | 'missing_warehouse'
  | 'missing_project_number'
  | 'missing_customer_name'
  | 'invalid_project_format'

import type { Requisition } from './data' // ✅ only import it — never define here

export function getIssues(row: Requisition): IssueType[] {
  const issues: IssueType[] = []
  if (row.status === 'Closed - General Cancel') return issues

  if (!row.order_date) issues.push('missing_order_date')
  if (!row.due_date) issues.push('missing_due_date')
  if (!row.created_by) issues.push('missing_created_by')
  if (!row.warehouse) issues.push('missing_warehouse')
  if (!row.project_number) issues.push('missing_project_number')
  if (!row.customer_name) issues.push('missing_customer_name')

  const projectFormat = /^LUT[\/-]REQ[\/-][A-Z]{2,6}[\/-]\d{3,6}[\/-]\d{4}$/
  if (row.project_number && !projectFormat.test(row.project_number)) {
    issues.push('invalid_project_format')
  }

  return issues
}
