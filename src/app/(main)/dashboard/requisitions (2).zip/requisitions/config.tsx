import { getRequisitionMetrics, getRequisitions } from '@/app/(main)/dashboard/requisitions/_components/data'
import type { DashboardConfig } from '@/components/dashboard/types'

export const requisitionsConfig: DashboardConfig = {
  id: 'requisitions',
  title: 'Requisitions Dashboard',
  range: '3m',
  rowIdKey: 'requisition_order_number',

  fetchRecords: getRequisitions,
  fetchMetrics: getRequisitionMetrics,

  filters: {
    status: 'status',
    creator: 'created_by',
    project: 'project_number',
    issue: true,
  },

  summary: [
    { key: 'totalAllTime', title: 'Total Requisitions', subtitle: 'All Time' },
    { key: 'issued', title: 'Issued', subtitle: 'Current' },
    { key: 'inProgress', title: 'In Progress', subtitle: 'Current' },
    { key: 'completed', title: 'Completed', subtitle: 'Current' },
    { key: 'cancelled', title: 'Cancelled', subtitle: 'Current' },
    { key: 'late', title: 'Late', subtitle: 'Current' },
  ],

  trends: [
    { key: 'totalReqs', title: 'Total Reqs' },
    { key: 'closedReqs', title: 'Closed - Pick Complete' },
    { key: 'missingOrderDate', title: 'Missing Order Date' },
    { key: 'missingDueDate', title: 'Missing Due Date' },
  ],

  tiles: [],

  widgets: [
    { component: 'SummaryCards', key: 'tiles', group: 'summary' },
    { component: 'SectionCards', key: 'tiles', group: 'trends' },
    { component: 'ChartAreaInteractive' },
    { component: 'ChartMissingData', filterType: 'issue' },
    { component: 'ChartByStatus', filterType: 'status' },
    { component: 'ChartByCreator', filterType: 'creator' },
    { component: 'ChartByProject', filterType: 'project' },
  ],

  tableColumns: [
    { accessorKey: 'requisition_order_number', header: 'Req Number' },
    { accessorKey: 'status', header: 'Status' },
    { accessorKey: 'created_by', header: 'Created By' },
    { accessorKey: 'project_number', header: 'Project' },
    { accessorKey: 'order_date', header: 'Order Date' },
    { accessorKey: 'due_date', header: 'Due Date' },
    { accessorKey: 'warehouse', header: 'Warehouse' },
  ],
}