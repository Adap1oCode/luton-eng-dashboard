'use client'

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'

export type SummaryTile = {
  title: string
  value: number | string | null
}

export default function SummaryCards({ data }: { data: SummaryTile[] }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-6">
      {data.map((tile, i) => (
        <Card key={i} className="@container/card">
          <CardHeader>
            <CardDescription>{tile.title}</CardDescription>
            <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
              {typeof tile.value === 'number' ? tile.value.toLocaleString() : tile.value ?? '—'}
            </CardTitle>
          </CardHeader>
        </Card>
      ))}
    </div>
  )
}
