export type IssueType =
  | 'missing_order_date'
  | 'missing_due_date'
  | 'missing_created_by'
  | 'missing_warehouse'
  | 'missing_project_number'
  | 'missing_customer_name'
  | 'invalid_project_format'

export function getIssues(row: Record<string, any>): IssueType[] {
  const issues: IssueType[] = []

  // Optional: skip if row has a cancelled status
  if (row.status === 'Closed - General Cancel') return issues

  // Core missing data checks
  if (!row.order_date) issues.push('missing_order_date')
  if (!row.due_date) issues.push('missing_due_date')
  if (!row.created_by) issues.push('missing_created_by')
  if (!row.warehouse) issues.push('missing_warehouse')
  if (!row.project_number) issues.push('missing_project_number')
  if (!row.customer_name && !row.vendor_name) issues.push('missing_customer_name')

  // Project number format check — only if it exists
  const formatRegex = /^LUT[\/-]REQ[\/-][A-Z]{2,6}[\/-]\d{3,6}[\/-]\d{4}$/
  if (row.project_number && !formatRegex.test(row.project_number)) {
    issues.push('invalid_project_format')
  }

  return issues
}
