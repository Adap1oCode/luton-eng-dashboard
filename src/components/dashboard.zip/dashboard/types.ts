// /components/dashboard/types.ts

export type DashboardWidget = {
  component: string
  filterType?: string
  key?: string
  group?: string // ✅ Added to support grouped tiles (e.g. 'summary', 'trends')
}

export type DashboardTile = {
  key: string
  title: string
  subtitle?: string // ✅ Optional subtitle for display under metric value
}

export type DashboardColumn = {
  accessorKey: string
  header: string
}

export type DashboardConfig = {
  id: string
  title: string
  range: '3m' | '6m' | '12m'
  rowIdKey: string

  fetchRecords: (range: string) => Promise<any[]>
  fetchMetrics: (range: string) => Promise<any>

  filters: {
    status?: string
    creator?: string
    project?: string
    issue?: boolean
    [key: string]: string | boolean | undefined
  }

  tiles: DashboardTile[]
  summary?: DashboardTile[] // ✅ Now allowed as part of config
  trends?: DashboardTile[]  // ✅ Now allowed as part of config

  widgets: DashboardWidget[]
  tableColumns: DashboardColumn[]
}

export type ClientDashboardConfig = Omit<DashboardConfig, 'fetchRecords' | 'fetchMetrics'>
