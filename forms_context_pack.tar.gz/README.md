# Forms Context Pack

This bundle includes only **forms-related** code and data:
- `src/app/(main)/forms/**` (screens, sections, hooks, screen-level types)
- `src/lib/data/**` (canonical types, DataProvider contract, mock provider)
- `src/data/mock/**` (JSON datasets)
- Select shared UI (`src/components/**`), theme, and styles

Use this when you want ChatGPT to reason strictly about *forms* — not dashboards or unrelated features.
