// File: src/app/(main)/dashboard/requisitions/_components/data-table.tsx

'use client'

import * as React from 'react'
import { useDataTableInstance } from '@/components/data-table/table-utils'
import { DataTable } from '@/components/data-table/data-table'
import { DataTablePagination } from '@/components/data-table/data-table-pagination'
import { DataTableViewOptions } from '@/components/data-table/data-table-view-options'
import { type ColumnDef } from '@tanstack/react-table'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'

interface DataTableShellProps<TData, TValue> {
  data: TData[]
  columns: ColumnDef<TData, TValue>[]
}

export function RequisitionTable<TData, TValue>({
  data,
  columns,
}: DataTableShellProps<TData, TValue>) {
  const table = useDataTableInstance({ columns, data })

  return (
    <Tabs defaultValue="outline" className="@container/card">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Requisitions</CardTitle>
          <CardDescription className="text-sm text-muted-foreground">
            Powered by Supabase
          </CardDescription>
          <TabsList className="mt-4">
            <TabsTrigger value="outline">Outline</TabsTrigger>
            <TabsTrigger value="past">Past Performance</TabsTrigger>
            <TabsTrigger value="team">Key Personnel</TabsTrigger>
          </TabsList>
        </CardHeader>

        <TabsContent value="outline">
          <CardContent className="flex flex-col gap-4">
            <DataTableViewOptions table={table} />
            <DataTable table={table} columns={columns} />
            <DataTablePagination
              page={table.getState().pagination.pageIndex + 1}
              totalPages={table.getPageCount()}
              onPageChange={(page) => table.setPageIndex(page - 1)}
            />
          </CardContent>
        </TabsContent>

        <TabsContent value="past">
          <CardContent className="text-muted-foreground text-sm">
            Coming soon: Past performance metrics
          </CardContent>
        </TabsContent>

        <TabsContent value="team">
          <CardContent className="text-muted-foreground text-sm">
            Coming soon: Team breakdown
          </CardContent>
        </TabsContent>
      </Card>
    </Tabs>
  )
}
