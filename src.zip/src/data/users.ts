export const users = [
  {
    id: "1",
    name: "Arham Khan",
    username: "Aarhamkhnz",
    email: "hello@arhamkhnz.com",
    avatar: "/avatars/arhamkhnz.png",
    role: "administrator",
  },
  {
    id: "2",
    name: "Ammar Khan",
    username: "ammarkhnz",
    email: "hello@ammarkhnz.com",
    avatar: "",
    role: "admin",
  },
];

export const rootUser = users[0];
