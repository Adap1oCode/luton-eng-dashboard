export default function Page() {
  return <>Coming Soon</>;
}
